import "./Sidebar.css";
import { NavLink } from "react-router-dom";

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <h3>Menu</h3>
      </div>

      <ul className="sidebar-menu">
        <li>
          <NavLink  to="/admin/dashboard" className={({ isActive }) => (isActive ? "active" : "")}>Dashboard</NavLink>
        </li>
        

        <li>
          <NavLink
            to="/admin/customers"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            Customers
          </NavLink>
        </li>

        <li>
          <NavLink
            to="/admin/reports"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            List of Quotations
          </NavLink>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;