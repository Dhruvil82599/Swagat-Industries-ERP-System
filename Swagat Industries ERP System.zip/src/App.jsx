// import Login from "../src/pages/Login/Login";
// import "./pages/Login/Login.css";
// import { Routes, Route } from "react-router-dom";
// import AdminPanel from "../src/pages/AdminPanel/AdminPanel";

// const App = () => {
//   return (

//   <Routes>
//     <Route path="/" element={<Login />} />
//     <Route path="/admin" element={<AdminPanel />} />
//   </Routes>

//   )
// };

// export default App;

import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login/Login";
import AdminPanel from "./pages/AdminPanel/AdminPanel";

import Dashboard from "./pages/Dashboard/Dashboard";
import Customers from "./pages/Customers/Customers";
import Reports from "./pages/Reports/Reports";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />

      <Route path="/admin" element={<AdminPanel />}>
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="customers" element={<Customers />} />
        <Route path="reports" element={<Reports />} />
      </Route>
    </Routes>
  );
}

export default App;
