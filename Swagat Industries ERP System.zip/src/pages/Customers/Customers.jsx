
import "./Customer.css"

const Customers = () => {
  return (
    <div className="customer-container">
      <div className="customer-form-card">
        <h2>Add Customer</h2>

        <form>
          <div className="form-row">
            <div className="form-group">
              <label>Customer Name</label>
              <input
                type="text"
                placeholder="Enter Customer Name"
              />
            </div>

            <div className="form-group">
              <label>Mobile Number</label>
              <input
                type="text"
                placeholder="Enter Mobile Number"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                placeholder="Enter Email Address"
              />
            </div>

            <div className="form-group">
              <label>City</label>
              <input
                type="text"
                placeholder="Enter City"
              />
            </div>
          </div>

          <div className="form-group">
            <label>Address</label>
            <textarea
              rows="4"
              placeholder="Enter Address"
            ></textarea>
          </div>

          <button type="submit" className="save-btn">
            Save Customer
          </button>
        </form>
      </div>
    </div>
  );
};

export default Customers;